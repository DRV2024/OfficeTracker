package com.example.officetracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OfficeTrackerApplication {

    public static void main(String[] args) {
        SpringApplication.run(OfficeTrackerApplication.class, args);
    }
}
