package com.example.officetracker.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.officetracker.model.Employee;
import com.example.officetracker.service.EmployeeService;

@Controller
public class EmployeeController {

    private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @GetMapping("/")
    public String index(Model model) {
        System.out.println("Hallo....Sai & Sai");
        model.addAttribute("employees", employeeService.getAllEmployees());

        return "index";
    }

    @PostMapping("/update-status")
    public String updateStatus(@RequestParam("name") String name, @RequestParam("status") String status) {
        Employee employee = new Employee(name, status);
        employeeService.saveEmployee(employee);
        return "redirect:/";
    }
}