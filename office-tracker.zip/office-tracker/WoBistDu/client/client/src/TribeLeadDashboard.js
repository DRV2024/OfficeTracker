import React, { useEffect, useState } from 'react';
import axios from 'axios';

const TribeLeadDashboard = () => {
  const [members, setMembers] = useState([]);

  useEffect(() => {
    const fetchMembers = async () => {
      try {
        const response = await axios.get('/api/tribes/:id/members');
        setMembers(response.data);
      } catch (error) {
        console.error('Failed to fetch members', error);
      }
    };

    fetchMembers();
  }, []);

  const handleStatusUpdate = async (memberId, status) => {
    try {
      await axios.put(`/api/tribes/:id/members/${memberId}`, { status });
      alert('Status aktualisiert');
    } catch (error) {
      console.error('Status update failed', error);
    }
  };

  return (
    <div className="dashboard-container">
      <h1>Mein Team</h1>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Status</th>
            <th>Raumnummer</th>
            <th>Letzte Aktualisierung</th>
            <th>Aktion</th>
          </tr>
        </thead>
        <tbody>
          {members.map((member) => (
            <tr key={member.user_id}>
              <td>{member.name}</td>
              <td>{member.status}</td>
              <td>{member.cubical_number}</td>
              <td>{member.last_update}</td>
              <td>
                <button onClick={() => handleStatusUpdate(member.user_id, 'Office')}>Status aktualisieren</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TribeLeadDashboard;