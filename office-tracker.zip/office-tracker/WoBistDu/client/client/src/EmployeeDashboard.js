import React, { useState } from 'react';
import axios from 'axios';

const EmployeeDashboard = () => {
  const [status, setStatus] = useState('Remote');
  const [cubicalNumber, setCubicalNumber] = useState('');

  const handleStatusUpdate = async () => {
    try {
      await axios.put('/api/users/me/status', { status, cubicalNumber });
      alert('Status aktualisiert');
    } catch (error) {
      console.error('Status update failed', error);
    }
  };

  return (
    <div className="dashboard-container">
      <h1>Mein Status</h1>
      <select value={status} onChange={(e) => setStatus(e.target.value)}>
        <option value="Office">Im Büro</option>
        <option value="Remote">Remote</option>
      </select>
      {status === 'Office' && (
        <input type="text" placeholder="Raumnummer" value={cubicalNumber} onChange={(e) => setCubicalNumber(e.target.value)} />
      )}
      <button onClick={handleStatusUpdate}>Status aktualisieren</button>
    </div>
  );
};

export default EmployeeDashboard;