import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Bar } from 'react-chartjs-2';

const AdminDashboard = () => {
  const [overview, setOverview] = useState({});

  useEffect(() => {
    const fetchOverview = async () => {
      try {
        const response = await axios.get('/api/admin/overview');
        setOverview(response.data);
      } catch (error) {
        console.error('Failed to fetch overview', error);
      }
    };

    fetchOverview();
  }, []);

  const exportReport = async (format) => {
    try {
      await axios.get(`/api/admin/reports?format=${format}`);
      alert('Bericht exportiert');
    } catch (error) {
      console.error('Report export failed', error);
    }
  };

  return (
    <div className="dashboard-container">
      <h1>Übersicht</h1>
      <Bar data={overview.chartData} />
      <button onClick={() => exportReport('pdf')}>Bericht exportieren (PDF)</button>
      <button onClick={() => exportReport('csv')}>Bericht exportieren (CSV)</button>
    </div>
  );
};

export default AdminDashboard;