const express = require('express');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/WoBistDu', { useNewUrlParser: true, useUnifiedTopology: true });

const UserSchema = new mongoose.Schema({
  user_id: String,
  name: String,
  email: { type: String, unique: true },
  password: String,
  role: String,
  tribe_id: String,
});

const TribeSchema = new mongoose.Schema({
  tribe_id: String,
  tribe_name: String,
  lead_id: String,
});

const StatusUpdateSchema = new mongoose.Schema({
  update_id: String,
  user_id: String,
  date: Date,
  status: String,
  cubical_number: String,
});

const User = mongoose.model('User', UserSchema);
const Tribe = mongoose.model('Tribe', TribeSchema);
const StatusUpdate = mongoose.model('StatusUpdate', StatusUpdateSchema);

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (user && bcrypt.compareSync(password, user.password)) {
    const token = jwt.sign({ user_id: user.user_id, role: user.role }, 'secret');
    res.json({ token });
  } else {
    res.status(401).send('Invalid credentials');
  }
});

app.get('/api/users/me', async (req, res) => {
  const token = req.headers.authorization.split(' ')[1];
  const decoded = jwt.verify(token, 'secret');
  const user = await User.findOne({ user_id: decoded.user_id });
  res.json(user);
});

app.put('/api/users/me/status', async (req, res) => {
  const token = req.headers.authorization.split(' ')[1];
  const decoded = jwt.verify(token, 'secret');
  const { status, cubical_number } = req.body;
  const update = new StatusUpdate({ update_id: new mongoose.Types.ObjectId(), user_id: decoded.user_id, date: new Date(), status, cubical_number });
  await update.save();
  res.send('Status updated');
});

app.get('/api/tribes/:id/members', async (req, res) => {
  const members = await User.find({ tribe_id: req.params.id });
  res.json(members);
});

app.put('/api/tribes/:id/members/:member_id', async (req, res) => {
  const { status } = req.body;
  await StatusUpdate.updateOne({ user_id: req.params.member_id }, { status });
  res.send('Status updated');
});

app.get('/api/admin/overview', async (req, res) => {
  const overview = {}; // Generate overview data
  res.json(overview);
});

app.get('/api/admin/reports', async (req, res) => {
  const { format } = req.query;
  // Generate and send report
  res.send(`Report exported as ${format}`);
});

app.listen(5000, () => {
  console.log('Server is running on port 5000');
});